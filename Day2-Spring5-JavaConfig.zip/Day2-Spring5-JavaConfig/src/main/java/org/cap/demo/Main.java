package org.cap.demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class Main {

	public static void main(String[] args) {
			
		AbstractApplicationContext cntx= new AnnotationConfigApplicationContext(JavaConfig.class);
		
		Employee employee=cntx.getBean(Employee.class);
		
		Employee employee1=cntx.getBean(Employee.class);
		
		employee1.setEmployeeName("ANiiee");
		System.out.println(employee);
		
		System.out.println(employee1);
		
		Student student=cntx.getBean(Student.class);
		System.out.println(student);
		cntx.registerShutdownHook();
		

	}

}
