package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Scope;

@Import({myConfig.class})
@Configuration
public class JavaConfig {
		
			@Bean
			//@Scope("prototype")
			public Employee getEmployee() {
				Employee emp=new Employee();
				emp.setEmployeeId(2002);
				emp.setEmployeeName("Roopa");
				emp.setAge(22);
				emp.setSalary(25456);
				return emp;
			}
			
				@Bean
				public Address getAddress() {
				Address add=new Address();
				add.setDoorno("22/e");
				add.setStreetName("South cr road");
				add.setCity("Bhimavaram");
				return add;
				
			}
}
