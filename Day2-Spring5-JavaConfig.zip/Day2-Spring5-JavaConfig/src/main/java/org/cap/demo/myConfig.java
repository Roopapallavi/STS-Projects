package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class myConfig {
	
				@Bean
				public Student getStudBean() {
					Student stud=new Student();
					stud.setStudId(45);
					stud.setStudName("Swaroopa");
					return stud;
					
				}
}
