package org.cap.model;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpademo");
		EntityManager em = factory.createEntityManager();
		EntityTransaction transaction=em.getTransaction();
		transaction.begin();
		Pilot pilot = new Pilot(45,"Swaroopa","Sannidhi",new Date(5/15/1998),new Date(5/15/2018), true, "swaroop.sanidhi@gmail.com",25000 );
		em.persist(pilot);
		transaction.commit();
		//System.out.println("Added one Student with address to database.");
		em.close();
		factory.close();
	}

}
