package org.cap.model;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Pilot implements Serializable {
				@Id
				@GeneratedValue
				private int pilotId;
				private String FirstName;
				private String LastName;
				
				private Date DateofBirth;
				private Date DateofJoining;
				private Boolean IsCertified;
				private String Email;
				
				private double Salary;
				public Pilot(int pilotId, String firstName, String lastName, Date dateofBirth, Date dateofJoining,
						Boolean isCertified, String email, double salary) {
					super();
					this.pilotId = pilotId;
					FirstName = firstName;
					LastName = lastName;
					DateofBirth = dateofBirth;
					DateofJoining = dateofJoining;
					IsCertified = isCertified;
					Email = email;
					Salary = salary;
				}
				
				
				@Override
				public String toString() {
					return "Pilot [pilotId=" + pilotId + ", FirstName=" + FirstName + ", LastName=" + LastName
							+ ", DateofBirth=" + DateofBirth + ", DateofJoining=" + DateofJoining + ", IsCertified="
							+ IsCertified + ", Email=" + Email + ", Salary=" + Salary + "]";
				}
				public String getEmail() {
					return Email;
				}
				public void setEmail(String email) {
					Email = email;
				}
			
				
				public Pilot() {
					super();
				}
			
			
				
				public Boolean getIsCertified() {
					return IsCertified;
				}
				public void setIsCertified(Boolean isCertified) {
					IsCertified = isCertified;
				}
				
				public int getPilotId() {
					return pilotId;
				}
				public void setPilotId(int pilotId) {
					this.pilotId = pilotId;
				}
				public String getFirstName() {
					return FirstName;
				}
				public void setFirstName(String firstName) {
					FirstName = firstName;
				}
				public String getLastName() {
					return LastName;
				}
				public void setLastName(String lastName) {
					LastName = lastName;
				}
				public Date getDateofBirth() {
					return DateofBirth;
				}
				public void setDateofBirth(Date dateofBirth) {
					DateofBirth = dateofBirth;
				}
				public Date getDateofJoining() {
					return DateofJoining;
				}
				public void setDateofJoining(Date dateofJoining) {
					DateofJoining = dateofJoining;
				}
				
				public double getSalary() {
					return Salary;
				}
				public void setSalary(double salary) {
					Salary = salary;
				}
				
				
}
