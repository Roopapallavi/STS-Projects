package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Login;
import org.cap.model.Pilot;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("pilotDao")

public class PilotDaoImpl implements PilotDao {
		
			@PersistenceContext
			private EntityManager entityManager;
			
			/*@Transactional
			@Override
			public void save(Pilot pilot) {
				entityManager.persist(pilot);
			}*/
	
			@Transactional(readOnly=true)
			@Override
			public List<Pilot> getAll() {
				List<Pilot> pilots = entityManager.createQuery("from Pilot").getResultList();
				return pilots;
			}
			@Transactional
			@Override
			public void delete(Integer pilotId) {
				Pilot pilot=entityManager.find(Pilot.class,pilotId);
				entityManager.remove(pilot);
			}
			
			@Transactional
			@Override
			public Pilot findPilot(Integer pilotId) {
				Pilot pilot=entityManager.find(Pilot.class,pilotId);
				return pilot;
				
				
			}
			
			@Transactional
			@Override
			public void update(Pilot pilot) {
				Pilot pilot1=entityManager.find(Pilot.class,pilot.getPilotId());
				if(pilot1==null)
					entityManager.persist(pilot);	
				else
					entityManager.merge(pilot);
			}
			@Override
			public boolean validate(String userName, String password) {
				Login user=entityManager.find(Login.class,userName);
				if(user!=null)
					if(userName.equals(user.getUserName()) && password.equals(user.getPassword()))
						return true;
				return false;
			}
			
			
			
			
			/*
			@Transactional
			@Override
			public void update(Student student) {
				Student student1= entityManager.find(Student.class, student.getStudId());
				if(student1==null)
					entityManager.persist(student);	
				else
					entityManager.merge(student);	
			}
			
			@Transactional
			@Override
			public Student findStudent(Integer studId) {
				Student student= entityManager.find(Student.class, studId);
				return student;
			}
			*/

}
