package org.cap.model;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.cap.annotation.NameValidator;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;


@Entity
public class Pilot implements Serializable {
				
				@Id
				@GeneratedValue
				private int pilotId;
				@NotEmpty(message="* Please Enter First Name")
				//@NameValidator(message="* please Enter first Letter caps")
				private String FirstName;
				@NotEmpty(message="* Please Enter Last Name")
				private String LastName;
				@NotNull
				@Past(message="* Please enter past Date")
				private Date DateofBirth;
				@Future(message="* Enter future date" )
				private Date DateofJoining;
				private Boolean IsCertified;
				
				@Range
				private double Salary;
			
			
			
				
				public Pilot(int pilotId, String firstName, String lastName, Date dateofBirth, Date dateofJoining,
						Boolean isCertified, double salary) {
					super();
					this.pilotId = pilotId;
					FirstName = firstName;
					LastName = lastName;
					DateofBirth = dateofBirth;
					DateofJoining = dateofJoining;
					IsCertified = isCertified;
					Salary = salary;
				}



				@Override
				public String toString() {
					return "Pilot [pilotId=" + pilotId + ", FirstName=" + FirstName + ", LastName=" + LastName
							+ ", DateofBirth=" + DateofBirth + ", DateofJoining=" + DateofJoining + ", IsCertified="
							+ IsCertified + ", Salary=" + Salary + "]";
				}



				public Pilot() {
					super();
				}
			
			
				
				public Boolean getIsCertified() {
					return IsCertified;
				}
				public void setIsCertified(Boolean isCertified) {
					IsCertified = isCertified;
				}
				
				public int getPilotId() {
					return pilotId;
				}
				public void setPilotId(int pilotId) {
					this.pilotId = pilotId;
				}
				public String getFirstName() {
					return FirstName;
				}
				public void setFirstName(String firstName) {
					FirstName = firstName;
				}
				public String getLastName() {
					return LastName;
				}
				public void setLastName(String lastName) {
					LastName = lastName;
				}
				public Date getDateofBirth() {
					return DateofBirth;
				}
				public void setDateofBirth(Date dateofBirth) {
					DateofBirth = dateofBirth;
				}
				public Date getDateofJoining() {
					return DateofJoining;
				}
				public void setDateofJoining(Date dateofJoining) {
					DateofJoining = dateofJoining;
				}
				
				public double getSalary() {
					return Salary;
				}
				public void setSalary(double salary) {
					Salary = salary;
				}
				
				
}
