package org.cap.annotation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;

@Constraint(validatedBy=NameConstraintValidator.class)
@Retention(RUNTIME)
@Target({ FIELD, METHOD })
public @interface NameValidator {

	public String value() default "firstName";
	public String message() default "must start with CAP";
	public Class<?>[] groups() default{};
}
