package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Student;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("studentDao")
public class StudentDaoImpl implements IStudentDao {
	
	 @PersistenceContext
		private EntityManager entityManager; 

	@Override
	@Transactional(readOnly=true)
	public List<Student> getStudentPage() {
		List<Student> students=entityManager.createQuery("from Student").getResultList();
		return students;
	}
	@Transactional
	@Override
	public Student findStudent(Integer studId) {
		Student student= entityManager.find(Student.class, studId);
		return student;
	}
	@Transactional
	@Override
	public void update(Student student) {
		Student student1= entityManager.find(Student.class, student.getStudId());
		if(student1==null)
			entityManager.persist(student);	
		else
			entityManager.merge(student);	
	}

	
					
}
