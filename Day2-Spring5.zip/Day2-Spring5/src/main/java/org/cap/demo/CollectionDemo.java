package org.cap.demo;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollectionDemo {
	
	private List<String> names;
	private List <Address> address;
	private Set <String> fruits;
	private Set<Address> address2;
	private Map<Integer, String> map;
	
	private Properties myprops;

	public Properties getMyprops() {
		return myprops;
	}
	public void setMyprops(Properties myprops) {
		this.myprops = myprops;
	}
	public Map<Integer, String> getMap() {
		return map;
	}
	public void setMap(Map<Integer, String> map) {
		this.map = map;
	}
	public Set<Address> getAddress2() {
		return address2;
	}
	public void setAddress2(Set<Address> address2) {
		this.address2 = address2;
	}
	public CollectionDemo() {
		super();
	}
	public List<String> getNames() {
		return names;
	}
	public void setNames(List<String> names) {
		this.names = names;
	}
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	public Set<String> getFruits() {
		return fruits;
	}
	public void setFruits(Set<String> fruits) {
		this.fruits = fruits;
	}
	
	
	
	
	
	
	
	 
}
