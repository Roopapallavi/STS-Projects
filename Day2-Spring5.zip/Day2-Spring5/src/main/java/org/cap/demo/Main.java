package org.cap.demo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		AbstractApplicationContext context=
						new ClassPathXmlApplicationContext("myBean.xml");
		
		CollectionDemo demo=(CollectionDemo)context.getBean("CollDemo");
		
		System.out.println(demo.getNames());
		System.out.println(demo.getAddress());
		System.out.println(demo.getAddress2());
		System.out.println(demo.getFruits());
		System.out.println(demo.getMap());
		System.out.println(demo.getMyprops());
		context.close();

	}

}
