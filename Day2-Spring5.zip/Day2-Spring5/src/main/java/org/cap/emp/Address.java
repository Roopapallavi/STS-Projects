package org.cap.emp;

public class Address {
			
	private String Doorno;
	private String StreetName;
	private String City;
	
	public Address() {
		super();
		System.out.println("Address Class Constructor");
	}
	
	@Override
	public String toString() {
		return "Adress [Doorno=" + Doorno + ", StreetName=" + StreetName + ", City=" + City + "]";
	}
	public String getDoorno() {
		return Doorno;
	}
	public void setDoorno(String doorno) {
		Doorno = doorno;
	}
	public String getStreetName() {
		return StreetName;
	}
	public void setStreetName(String streetName) {
		StreetName = streetName;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	
	
	
}
