package org.cap.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		/*AbstractApplicationContext context=
				new ClassPathXmlApplicationContext("myBean.xml");*/
		AbstractApplicationContext context=new FileSystemXmlApplicationContext("D:\\Users\\sswaroop\\Desktop\\myBean.xml");
			Employee employee=(Employee)context.getBean("employee");
			
			Employee employee1=(Employee)context.getBean("employee");
			
			Employee employee2=(Employee)context.getBean("employee1");
			
			employee1.setEmployeeName("jack");
			
			System.out.println(employee);
			System.out.println(employee1);
			System.out.println(employee2);
			
			context.registerShutdownHook();
	}

}
