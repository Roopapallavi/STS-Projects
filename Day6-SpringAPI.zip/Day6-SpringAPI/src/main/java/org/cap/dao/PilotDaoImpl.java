package org.cap.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
public class PilotDaoImpl implements PilotDao {
	
				private static AtomicInteger pilotId=new AtomicInteger(1000);
				private static List<Pilot> pilots=dummyDbPilot();
	
	
	@Override
	public List<Pilot> getAllPilots() {
		

		return pilots;
	}


	private static List<Pilot> dummyDbPilot() {
		List<Pilot> pilots=new ArrayList();
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Tom","Jerry",new Date(1991,03,12),new Date(),true,54000));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Ram","Juli",new Date(1992,06,21),new Date(),false,54000));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Sita","jack",new Date(1996,9,22),new Date(),true,44000));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Raj","Jessi",new Date(1998,10,9),new Date(),false,55600));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Sai","ravi",new Date(1994,11,22),new Date(),true,54870));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Shiva","roopa",new Date(1999,9,30),new Date(),false,34500));
		return pilots;
	}

}
